/**
 * File: symtable.h
 * ----------- 
 *  Header file for Symbol table implementation.
 */

